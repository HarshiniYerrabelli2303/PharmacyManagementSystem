export class Drugs{
    drugId:any
	 suplierEmail:String=""
	 drugName:String=""
	  quantity:number=0
	  batchId:number=0
	  expiredDate:String=""
	  price:number=0

}
export interface serverResponse  {
	count: number;
	products: Drugs[]
  };