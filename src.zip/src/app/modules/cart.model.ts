import { Drugs } from "./drugs";


export interface CartModelServer {
  total: Number;
  data: [{
    product: Drugs,
    numInCart: Number
  }];
}

export interface CartModelPublic {
  total: Number;
  prodData: [{
    id: Number,
    incart: Number
  }]
}
