import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Users } from '../modules/users';
import { AuthenticationService } from '../services/authentication.service';
import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-doctor-home',
  templateUrl: './doctor-home.component.html',
  styleUrls: ['./doctor-home.component.css']
})
export class DoctorHomeComponent implements OnInit {
  userName:string='';
  users: Users= new Users(); 
  constructor( private router : Router,public loginService:AuthenticationService,private userservice: UsersService,
    private activatedRoute: ActivatedRoute, ) { }

  ngOnInit(): void {
  }
  

  viewProfile(userId:number,firstName:string,lastName:string,gender:string,email:string,phone:string,role:string,userName:string){
    this.users.userId=userId
    this.users.firstName=firstName
    this.users.lastName=lastName
    this.users.email=email
    this.users.gender=gender
    this.users.phone=phone
    this.users.role=role
    this.users.userName=userName
    this.router.navigate(['viewProfile',userName])
    }
}
