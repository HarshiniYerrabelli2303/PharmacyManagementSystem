import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { CartComponent } from './cart/cart.component';

import { DashboardComponent } from './dashboard/dashboard.component';
import { DoctorHomeComponent } from './doctor-home/doctor-home.component';
import { DrugsComponent } from './drugs/drugs.component';
import { UpdateDrugsComponent } from './drugs/update-drugs/update-drugs.component';
import { ViewAllDrugsComponent } from './drugs/view-all-drugs/view-all-drugs.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { OrderComponent } from './order/order.component';
import { ProductsComponent } from './products/products.component';
import { RegisterComponentComponent } from './register-component/register-component.component';
import { AuthGaurdService } from './services/auth-gaurd.service';
import { UpdateProfileComponent } from './update-profile/update-profile.component';
import { ViewAllUsersComponent } from './view-all-users/view-all-users.component';
import { ViewComponentComponent } from './view-component/view-component.component';


const routes: Routes = [
  { path: 'viewDrug', component: ViewAllDrugsComponent },
  { path: 'updateDrug/:id', component:UpdateDrugsComponent },
  { path: 'addDrugs', component:DrugsComponent },
  { path: 'dashboard', component:DashboardComponent},
  { path: 'products', component:ProductsComponent},
  { path : 'register' , component:RegisterComponentComponent},
{ path : 'viewProfile', component:ViewComponentComponent},
{ path : 'login', component: LoginComponent },
{ path : 'logout', component: LogoutComponent, canActivate: [AuthGaurdService] },
{ path : 'doctorhome' , component:DoctorHomeComponent},
{ path : 'adminhome', component:AdminHomeComponent},
{ path : 'viewAllUsers' , component:ViewAllUsersComponent},
{ path : 'update/:userId', component:UpdateProfileComponent},
  { path: 'cart', component:CartComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
