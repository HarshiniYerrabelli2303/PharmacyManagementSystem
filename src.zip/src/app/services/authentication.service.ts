import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

export class User {
  constructor(
    public status: string,
  ) { }

}

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(
    private httpClient: HttpClient
  ) {
  }

  authenticate(userName : any  , password : any) {
  
    var body = JSON.stringify({ "userName": userName , "password": password})
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    return this.httpClient.post('http://localhost:8084/users/login', body, { headers: headers, responseType: 'text' }).pipe(
      map(
        userData => {
          sessionStorage.setItem('userName', userName);
          sessionStorage.setItem('password', password);
          var role=userData.split("USERTYPE")
          sessionStorage.setItem('role', role[1]);
          sessionStorage.setItem('token', 'Bearer ' );
          console.log(userName)
          console.log(role[0])
          console.log(role[1])
          console.log(sessionStorage.getItem('token'))
          return userData;
        }
      )

    );
  }


  isUserLoggedIn() {
    let user = sessionStorage.getItem('userName')
     console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('userName')
    sessionStorage.removeItem('password')
    sessionStorage.removeItem('role')
    sessionStorage.removeItem('authority')
    sessionStorage.removeItem('userId')
     sessionStorage.removeItem('token')
  }

  
}
